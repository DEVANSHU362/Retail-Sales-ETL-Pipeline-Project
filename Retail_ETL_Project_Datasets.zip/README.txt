Retail ETL Project Datasets

Tables:
- customers.csv (~8001 rows incl. duplicate)
- products.csv (~2001 rows incl. duplicate)
- stores.csv (100 rows)
- orders.csv (~50001 rows incl. duplicate)

Intentional data quality issues:
- Null values
- Duplicate rows
- Missing prices/emails/city/quantity

Join Keys:
orders.Customer_ID -> customers.Customer_ID
orders.Product_ID -> products.Product_ID
orders.Store_ID -> stores.Store_ID
